=== Mechanic Visitor Counter ===
Contributors: adityasubawa
Donate link: http://www.adityasubawa.com/
Tags: Visitor counter, visitor traffic, traffic statistics, traffic counter, blog stats, blog traffic, traffic count
Requires at least: 4.5.3
Tested up to: 4.6.1
Stable tag: 3.1

Mechanic Visitor Counter is a widgets which will display the Visitor counter and traffic statistics on WordPress. Some of the features offered include Today Visitor, Today Hits, Total Hits, Total Visit, Who's Online and IP Address Visitors.

== Description ==

Mechanic Visitor Counter is a widgets which will display the Visitor counter and traffic statistics on WordPress.Some of the features offered include Today Visitor, Today Hits, Total Hits, Total Visit, Who's Online and IP Address Visitors.

Upload and Install WordPress Visitor Counter Plugins, Activate and Drag the Widgets in to your WordPress Sidebar. And this plugins will useless for a thousands of websites. If you were here, download and install it, you�ll like it.


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload 'statsmechanic.zip' to the '/wp-content/plugins/' directory. You can do this using 'Upload' functionality provided in plugins section of your wordpress dashboard
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 'Appearance' >> 'Widgets' and drag 'Visitor COunter' in to your WordPress sidebar
4. Save
5. You are done. 

== Frequently Asked Questions ==

= How to add more counter Images? =

As of now, adding another counter images, you can do to access the folder "styles/image/" on the installation of plugins

= How to add language? =

Since version 3.1 to contribute to translate, please email me at me@adityasubawa.com. Or just take the example in plugin installation "languages" folder -> wp-statsmechanic-en_GB.po

== Screenshots ==

1. Sample display
2. Widget options
3. Image counter options

== Changelog ==

= 1.0 = 

Upgrage to 1.1 version

= 1.1 =

Upgrage to 1.2 version

= 1.2 =

Fix images system, upgrade to 1.3 version

= 1.3 =

Upgrage to 1.4 version

= 1.4 =

Fix author credit options, upgrade to 1.5 version

= 1.5 =

Upgrage to 1.6 version

= 1.6 =

Upgrage to 1.7 version

= 1.7 =

Fix image issues, Upgrage to 1.8 version

= 1.8 =

Fix auto hide IP address and Server Time, Upgrage to 2.0 version

= 2.0 =

Adding new feature option in the widgets area.

= 2.1 =

Adding Image Counter styles and align options. 

= 2.2 =

fix image patch. 

= 2.3 =

upgrade to 2.4 version

= 2.4 =

fix total hits and widget options.

= 2.5 =

adding yesterday, this month, this year statistics

= 2.6 =

fix / path of some image

= 2.7 =

Universal Image path

= 2.9 =

remove author credit selector

= 3.0 =

1. fix primary on table
1. adding view and hits starting number
1. remove 3 image counter
1. upgrade options setting
1. fix privilage access

= 3.1 =

1. adding localization or translation
1. adding PHP Version compability
1. adding 3 image counter style
1. fix php and mysql query

= 3.2 =
1. fix readme.txt

= 3.2.1 =
1. adding plugin credit option
1. adding count start at Total Visit

= 3.2.2 =
1. adding turkish language, contribution by Yunus BOZKURT
1. adding image count length

Plug-in is now compatible upto wordpress version 4.7


== Arbitrary section ==

Refer Installation and FAQ section for all required information

== A brief Markdown Example ==

Ordered list:

1. Most simple plugin available so far
1. Do not remove or modify developer plugins link, just use plugin credit option in widget 

== Upgrade Notice ==
Upgrade your already installed plug-ins to latest version 3.2.2