=== Animated Headline ===
Contributors: anshuln90
Tags: animation, ext, shortcode, effect, animated text, super text, best plugin, super effect, animated effect, anshullabs, anshulg90, anshul, wordpress, animation effect, style, editor, code, animation code
Donate link: http://www.paypal.me/anshulgangrade
Requires at least: at least: 3.5
Tested up to: 4.9.4
Stable tag: 4.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Super animation headline by using shortcode. Easy to use and look super animated headline. 

== Description ==
Animated Headline is a plugin to show, animated headline using short-code. It was very easy to use, Just use animated headline shortcode. 

= Example: =
[animated-headline title="Hello my friend" animated_text="Anshul,Rahul,Nisha" animation="clip"]

Here you can select 10 type of animation effect for changing text effect. For more detail you can check plgin detail page, You will find 'Animated Headlines' menu under settings in your WordPress admin panel. Here you can see how to use and more detail.

<a href="http://www.paypal.me/anshulgangrade" rel="nofollow">Donate Me</a>


== Installation ==
1. Upload animated-headline.zip to the /wp-content/plugins/ directory
2. Unzip animated-headline.zip
3. Activate the plugin through the 'Plugins' menu in WordPress
4. You will find 'Animated Headlines' under setting menu in your WordPress admin panel.

== Frequently Asked Questions ==
= 1) How to Use ? =
Use shortcode like [animated-headline title="Hello my friend" animated_text="Anshul,Rahul,Nisha" animation="clip"]
and You will find 'Animated Headlines' under setting menu in your WordPress admin panel.

== Screenshots ==
1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png

== Changelog ==
=4.0=
Remove Some Bugs and Update plugin.
=3.5=
Fixed Some Bugs and Update plugin.
=3.0=
Remove Some Bugs and Update plugin.
=2.0=
Remove Some Bugs and Update plugin.
=1.5=
Remove Some Bugs.
=1.0=
Initial Release.


== Upgrade Notice ==
Update some bugs in version 1.0
Update plugin in version 1.5
Update plugin in version 2.0
Update plugin in version 3.0
Update plugin in version 3.5
Update plugin in version 4.0