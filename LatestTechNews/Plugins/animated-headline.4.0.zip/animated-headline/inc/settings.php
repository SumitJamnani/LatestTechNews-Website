<div class="wrap">
    <h2>Animated Headlines</h2>
    <h3>1) How to Use ?</h3>
    <p><b>Answer :</b> Just Use shorcode, Example : <b> [animated-headline title="Hello my friend" animated_text="Anshul,Rahul,Nisha" animation="clip"]</b>. <br> Where <code>title</code> is starting text. then <code>animated_text</code> is animated text and <code>animation</code> is effect type.  </p>
	
	<h3>2) How much nuber of Animation Effect we use ?</h3>
	<p><b>Answer :</b> In this plugin you can select 10 type of Effect of animation. the animation effect type list below.</p>
	<ol>
		<li>rotate-1</li>
		<li>rotate-2</li>
		<li>rotate-3</li>
		<li>type</li>
		<li>scale</li>
		<li>loading-bar</li>
		<li>slide</li>
		<li>clip</li>
		<li>zoom</li>
		<li>push</li>
	</ol>

	<h3>3) How to Donate ?</h3>
	<p><b>Answer :</b> Click below link to Donate us. <br>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
			<input type="hidden" name="cmd" value="_donations">
			<input type="hidden" name="business" value="anshul.gangrade2@gmail.com">
			<input type="hidden" name="lc" value="US">
			<input type="hidden" name="item_name" value="Animation Headline Wordpress Plugin - Anshul Labs">
			<input type="hidden" name="no_note" value="0">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="bn" value="PP-DonationsBF:btn_donateCC_LG.gif:NonHostedGuest">
			<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
		</form>
	</p>
</div>