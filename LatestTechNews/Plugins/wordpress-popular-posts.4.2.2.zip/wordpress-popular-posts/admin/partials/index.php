<?php 
// Silence is golden
