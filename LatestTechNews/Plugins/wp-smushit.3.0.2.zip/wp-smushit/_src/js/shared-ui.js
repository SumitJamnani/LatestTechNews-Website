/**
 * Shared UI JS libraries. Use only what we need to keep the vendor file size smaller.
 */
require('@wpmudev/shared-ui/dist/js/_src/modals');
require('@wpmudev/shared-ui/dist/js/_src/notifications');
require('@wpmudev/shared-ui/dist/js/_src/scores');
require('@wpmudev/shared-ui/dist/js/_src/select');
