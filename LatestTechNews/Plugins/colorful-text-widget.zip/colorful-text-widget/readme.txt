=== Colorful text widget ===
Contributors: iniyan, logeshmba
Donate link: http://thamiziniyan.com/
Tags: text, text widget, custom class, custom text, colorful
Requires at least: 2.8
Tested up to: 4.9.4
Stable tag: 3.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Colorful Text Widgets is a normal text widget that makes your text widget a colorful one. 

== Description ==

Colorful Text Widgets is a normal text widget that makes your text widget a colorful one. You can change the color of Title, Background and Text using the color-pickers provided with in the widget itself.

More style options will be added on further release. 


== Installation ==

Upload to plugins directory and activate it on appearance-plugins. Colorful text widget will appear in the appearances > widgets section.

== Frequently Asked Questions ==

= Does this plugin really needed one? =

That's upto you :)

== Changelog ==

= 1.0.0 =
* first release

= 3.0.0 =
* You can change background of Title
* Compatible test upto latest WordPress Version

== Upgrade Notice ==

= 1.0 =
Fresh release.

= 2.0 =
* Added color picker to change Background, Ttile and Text color


= 2.0.2=
tested upto 4.1. Small fix.

= 2.0.3=
Added border radius option

=3.0.0=
* You can change background of Title

=3.0.1=
* Compatible test upto latest WordPress Version

== Screenshots ==

It's not a rocket science. 
So, you really don't need one...
