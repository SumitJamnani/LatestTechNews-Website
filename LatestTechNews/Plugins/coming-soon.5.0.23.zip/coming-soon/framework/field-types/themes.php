<div id="seed-csp4-themes-preview">
<div class="seed-csp4-themes-preview-grid seed-csp4-clear">

    <div class="seed-csp4-themes-preview-item " > 
        <div class="seed-ribbon">
        <span>Pro</span>
        </div>   
        <a href="admin.php?page=seed_csp4_themes"><img  src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/themes/1.jpg"></a>
    </div>

    <div class="seed-csp4-themes-preview-item " > 
    <div class="seed-ribbon">
        <span>Pro</span>
        </div>    
        <a href="admin.php?page=seed_csp4_themes"><img  src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/themes/22.jpg"></a>
    </div>

    <div class="seed-csp4-themes-preview-item " >  
    <div class="seed-ribbon">
        <span>Pro</span>
        </div>   
        <a href="admin.php?page=seed_csp4_themes"><img  src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/themes/37.jpg"></a>
    </div>

    <div class="seed-csp4-themes-preview-item " >  
    <div class="seed-ribbon">
        <span>Pro</span>
        </div>   
        <a href="admin.php?page=seed_csp4_themes"><img  src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/themes/51.jpg"></a>
    </div>

        <div class="seed-csp4-themes-preview-item " >  
    <div class="seed-ribbon">
        <span>Pro</span>
        </div>   
        <a href="admin.php?page=seed_csp4_themes"><img  src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/themes/19.jpg"></a>
    </div>

            <div class="seed-csp4-themes-preview-item " >  
    <div class="seed-ribbon">
        <span>Pro</span>
        </div>   
        <a href="admin.php?page=seed_csp4_themes"><img  src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/themes/31.jpg"></a>
    </div>

                <div class="seed-csp4-themes-preview-item " >  
    <div class="seed-ribbon">
        <span>Pro</span>
        </div>   
        <a href="admin.php?page=seed_csp4_themes"><img  src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/themes/18.jpg"></a>
    </div>

                    <div class="seed-csp4-themes-preview-item " >  
    <div class="seed-ribbon">
        <span>Pro</span>
        </div>   
        <a href="admin.php?page=seed_csp4_themes"><img  src="<?php echo SEED_CSP4_PLUGIN_URL ?>public/images/themes/23.jpg"></a>
    </div>

</div>
<p style="font-size:13px">Click any theme to see the 50+ themes include in the Pro Version.</p>
</div>

<div id="seed-csp4-themes-preview-gradient">
</div>