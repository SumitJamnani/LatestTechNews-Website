<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly
?>
<input type="submit" name="dlm_checkout_submit" id="dlm_checkout_submit" value="<?php _e('Complete order','download-monitor'); ?>" />