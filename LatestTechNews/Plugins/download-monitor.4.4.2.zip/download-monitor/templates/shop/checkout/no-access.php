<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly
?>
<p><?php _e( 'You have no access to this order.', 'download-monitor' ); ?></p>
